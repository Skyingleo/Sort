const fs = require('fs');
let txt = fs.readFileSync('./small_closed.xml');
const quickSort = require('./quickSort.js');

let title = [];
let id = [];
let text = [];
let index = [];
let words = [];
var dic = {};

var search = "";


const readline = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout
})

readline.question(`Please enter a word to search for!`, name => {
  console.log(`Searching ${name}, please wait patiently!`)
  if(name == null || name == ""){
    console.log("CANNOT BE BLANK!")
    readline.close()
  }else{
    search = name;
    /*readline.close()*/

    let pages = sort(txt);
    find(pages);

    let test = ["I like like the book", "she like school."];
    getEverything(sort(txt));
    readline.close()
  }
})

function sort(file){
 let input = file.toString();
 nbLines = (input.split("\n")).length;
  temp_file = input.split('\n');
  let pages = [];
  let initial;
  let final;
  let nOfPages = 0;
  for(let i = 0; i < nbLines; i++){
   if (temp_file[i] =='<page>'){
    initial = i;
   }
   if (temp_file[i] =='</page>'){
      final = i;
    }
    if (final > initial){
      pages[nOfPages] = temp_file.slice(initial, final+1).join('');
      nOfPages++;
    }
  }

  for (let i = 0; i < nOfPages; i++){
   for (let j = 0; j < pages[i].length; j++){
    if (pages[i].substring(j,j+6) == "<page>"){
       pages[i] = pages[i].substring(0, j+6) + "\n" + pages[i].substring(j+6);
      }
      if (pages[i].substring(j,j+6) == "<text>"){
       pages[i] = pages[i].substring(0, j+6) + "\n" + pages[i].substring(j+6);
      }
      if (pages[i].substring(j,j+8) == "</title>"){
       pages[i] = pages[i].substring(0, j+8) + "\n" + pages[i].substring(j+8);
      }
      if (pages[i].substring(j,j+5) == "</id>"){
       pages[i] = pages[i].substring(0, j+5) + "\n" + pages[i].substring(j+5);
      }
      if (pages[i].substring(j,j+7) == "</text>"){
       pages[i] = pages[i].substring(0, j+7) + "\n" + pages[i].substring(j+7);
      }
     }
 }
 return pages;
}

//console.log(sort(txt));

function find(array) {
 for (let i = 0; i < array.length; i++) {
   let lines = array[i].split("\n");
    title.push(lines[1].substring(7, lines[1].length-8));
    id.push(lines[2].substring(4, lines[2].length-5));
    text.push(lines[4].substring(0, lines[4].length-7));
 }
 //console.log(id);
 //console.log(title);
  //console.log(text);
}

function getEverything(a) {
 for (let i = 0; i < a.length; i++) {
  var noPun = a[i].replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "");
  var sentence = noPun.split(" ");
  for (let j = 0; j < sentence.length; j++) {
   	if (dic[sentence [j]] != undefined){
   		let sameids = dic[sentence[j]] + " ,"+ id[i] ;
   		dic[sentence[j]] = sameids;
   	}else{
   		dic[sentence[j]] = [id[i]];
   	}
  }
 }

//  console.log(dic)
 if(search != null && search != ""){
  if(!dic.hasOwnProperty(search)){
    console.log("data not found")
  }else{
    var e = "dic."+search+"[0]";
    var v = eval(e);
    console.log(v)
    for(n = 0; n < id.length; n++){
        if(v == id[n]){
          v = n;
          break;
        }
    }

    console.log(text[n])
  }
 }else{
   console.log("CANNOT BE BLANK!")
 }
}

