function swap(arr, a, b){
 let temp = arr[a];
 arr[a] = arr[b];
 arr[b] = temp;
}

function QSort(array){

 if (array.length <= 1){
  return array;
 }

 let pivot = array[array.length-1];
 let LArray = [];
 let RArray = [];
 let position = -1;

 for (let i = 0; i < array.length-1; i++){
  if(array[i] < pivot){
   position = position + 1;
   swap(array, i, position);
  }
 }
    position++;
 swap(array, position, array.length-1);

 for (let a = 0; a < position; a++){
  LArray.push(array[a]);
 }

 for (let b = position+1; b < array.length; b++){
  RArray.push(array[b]);
 }

 LArray = QSort(LArray);
 RArray = QSort(RArray);

 return [...LArray, pivot, ...RArray];
}

function FQsort(str){
 return QSort(str.split('')).join('') + "|" + str;
}

function fullQuickSort(txt){
 let temp;
 temp = txt.toString().replace(/ /g, '').split('\r\n');
 for (let i = 0; i < temp.length; i++){
  temp[i] = FQsort(temp[i]+ "s");
    }
    return QSort(temp); 
}